import React, { useCallback, useEffect, useRef, useState } from 'react';
import { SafeAreaView, View, Text, Pressable, StatusBar, ActivityIndicator, Platform } from 'react-native';
import { supabase } from './src/supabase';
import Auth from './src/Auth';
import Week from './src/Week';
import Activities from './src/Activities';
import Team from './src/Team';
import Comments from './src/Comments';
import { C } from './src/ui';
import { ymd } from './src/util';

const TABS = [['week', 'Semana', '📅'], ['acts', 'Actividades', '🏃'], ['team', 'Equipo', '👥']];

export default function App() {
  const [session, setSession] = useState(undefined);
  const [tab, setTab] = useState('week');
  const [data, setData] = useState(null);
  const [target, setTarget] = useState(null);
  const timer = useRef(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: l } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => l.subscription.unsubscribe();
  }, []);

  const load = useCallback(async () => {
    const since = ymd(new Date(Date.now() - 120 * 864e5));
    const [p, t, w, a, d, c] = await Promise.all([
      supabase.from('profiles').select('*').order('name'), supabase.from('tasks').select('*'), supabase.from('weeks').select('*'),
      supabase.from('activities').select('*').gte('date', since).order('started_at', { ascending: false }),
      supabase.from('task_done').select('*'), supabase.from('comments').select('target_type,target_id'),
    ]);
    setData({ profiles: p.data || [], tasks: t.data || [], weeks: w.data || [], acts: a.data || [], done: d.data || [], cc: c.data || [] });
  }, []);
  const reload = useCallback(() => { clearTimeout(timer.current); return new Promise((res) => { timer.current = setTimeout(() => load().then(res), 150); }); }, [load]);

  useEffect(() => {
    if (!session) { setData(null); return; }
    load();
    const ch = supabase.channel('all').on('postgres_changes', { event: '*', schema: 'public' }, () => reload()).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [session?.user?.id]);

  if (session === undefined) return <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator /></View>;
  const me = data?.profiles.find((p) => p.id === session?.user?.id);
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg, paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0 }}>
      <StatusBar barStyle="dark-content" />
      {!session ? <Auth /> : !data || !me ? <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator /></View> : (
        <>
          <View style={{ flex: 1 }}>
            {tab === 'week' && <Week me={me} data={data} reload={reload} openComments={setTarget} />}
            {tab === 'acts' && <Activities me={me} data={data} reload={reload} openComments={setTarget} />}
            {tab === 'team' && <Team me={me} data={data} reload={reload} />}
          </View>
          <View style={{ flexDirection: 'row', borderTopWidth: 1, borderColor: C.line, backgroundColor: C.card }}>
            {TABS.map(([k, label, ic]) => (
              <Pressable key={k} onPress={() => setTab(k)} style={{ flex: 1, alignItems: 'center', paddingVertical: 8 }}>
                <Text style={{ fontSize: 20 }}>{ic}</Text>
                <Text style={{ fontSize: 12, color: tab === k ? C.accent : C.muted, fontWeight: tab === k ? '700' : '400' }}>{label}</Text>
              </Pressable>
            ))}
          </View>
          <Comments target={target} me={me} profiles={data.profiles} onClose={() => setTarget(null)} reload={reload} />
        </>
      )}
    </SafeAreaView>
  );
}
