-- Ejecuta esto entero en Supabase > SQL Editor
create type role_t as enum ('coach','runner','socio');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  name text, role role_t not null default 'runner',
  goal_km numeric default 30,
  strava_athlete_id bigint unique,
  created_at timestamptz default now()
);
create table strava_tokens (
  user_id uuid primary key references auth.users on delete cascade,
  athlete_id bigint, access_token text, refresh_token text, expires_at bigint
);
create table oauth_states (
  state text primary key, user_id uuid not null default auth.uid(), created_at timestamptz default now()
);
create table weeks (week_start date primary key, focus text);
create table tasks (
  id uuid primary key default gen_random_uuid(),
  week_start date not null, day int, title text not null, type text default 'rodaje',
  km numeric, notes text, assignee uuid references profiles(id) on delete set null,
  created_at timestamptz default now()
);
create table activities (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  strava_id bigint unique, source text default 'manual', name text, sport text,
  started_at timestamptz default now(), date date not null,
  km numeric not null, moving_sec int not null default 0, elev numeric default 0
);
create table task_done (
  task_id uuid references tasks on delete cascade, user_id uuid references profiles on delete cascade,
  primary key (task_id, user_id)
);
create table comments (
  id uuid primary key default gen_random_uuid(),
  target_type text not null check (target_type in ('week','task','activity')),
  target_id text not null, author uuid not null default auth.uid() references profiles(id) on delete cascade,
  to_user uuid references profiles(id) on delete set null,
  body text not null, private boolean not null default false, created_at timestamptz default now()
);

-- El primer usuario que se registra es coach; el resto, corredores.
create function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into profiles(id,name,role) values (
    new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)),
    case when exists(select 1 from profiles) then 'runner'::role_t else 'coach'::role_t end);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

create function is_coach() returns boolean language sql security definer stable set search_path=public as $$
  select exists(select 1 from profiles where id=auth.uid() and role='coach') $$;

create function set_role(uid uuid, r role_t) returns void language plpgsql security definer set search_path=public as $$
begin
  if not is_coach() then raise exception 'solo coaches'; end if;
  update profiles set role=r where id=uid;
end $$;

alter table profiles enable row level security;
alter table strava_tokens enable row level security;   -- sin políticas: solo el servidor
alter table oauth_states enable row level security;
alter table weeks enable row level security;
alter table tasks enable row level security;
alter table activities enable row level security;
alter table task_done enable row level security;
alter table comments enable row level security;

revoke update on profiles from authenticated;
grant update (name, goal_km) on profiles to authenticated;

create policy p_sel on profiles for select to authenticated using (true);
create policy p_upd on profiles for update to authenticated using (id=auth.uid());
create policy st_ins on oauth_states for insert to authenticated with check (user_id=auth.uid());
create policy w_sel on weeks for select to authenticated using (true);
create policy w_all on weeks for all to authenticated using (is_coach()) with check (is_coach());
create policy t_sel on tasks for select to authenticated using (true);
create policy t_all on tasks for all to authenticated using (is_coach()) with check (is_coach());
create policy a_sel on activities for select to authenticated using (true);
create policy a_ins on activities for insert to authenticated with check (user_id=auth.uid() and source in ('manual','import'));
create policy a_del on activities for delete to authenticated using (user_id=auth.uid() or is_coach());
create policy d_sel on task_done for select to authenticated using (true);
create policy d_ins on task_done for insert to authenticated with check (user_id=auth.uid());
create policy d_del on task_done for delete to authenticated using (user_id=auth.uid());
create policy c_sel on comments for select to authenticated using (not private or is_coach());
create policy c_ins on comments for insert to authenticated with check (author=auth.uid() and (not private or is_coach()));
create policy c_del on comments for delete to authenticated using (author=auth.uid() or is_coach());

alter publication supabase_realtime add table tasks, weeks, activities, task_done, comments, profiles;
