// Callback OAuth de Strava. Desplegar con: supabase functions deploy strava-auth --no-verify-jwt
import { admin, syncRecent } from '../_shared/strava.ts';

const APP = Deno.env.get('APP_SCHEME') ?? 'runteam://strava';
const back = (ok: boolean) => new Response(null, { status: 302, headers: { Location: `${APP}?ok=${ok ? 1 : 0}` } });

Deno.serve(async (req) => {
  const u = new URL(req.url);
  const code = u.searchParams.get('code'), state = u.searchParams.get('state');
  if (!code || !state || u.searchParams.get('error')) return back(false);
  const db = admin();
  const { data: st } = await db.from('oauth_states').select('user_id,created_at').eq('state', state).maybeSingle();
  if (!st || Date.now() - new Date(st.created_at).getTime() > 10 * 60 * 1000) return back(false);
  await db.from('oauth_states').delete().eq('state', state);

  const r = await fetch('https://www.strava.com/oauth/token', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: Deno.env.get('STRAVA_CLIENT_ID')!, client_secret: Deno.env.get('STRAVA_CLIENT_SECRET')!, code, grant_type: 'authorization_code' }),
  });
  if (!r.ok) return back(false);
  const t = await r.json();
  await db.from('strava_tokens').upsert({ user_id: st.user_id, athlete_id: t.athlete.id, access_token: t.access_token, refresh_token: t.refresh_token, expires_at: t.expires_at });
  await db.from('profiles').update({ strava_athlete_id: t.athlete.id }).eq('id', st.user_id);
  await syncRecent(db, st.user_id, 60);   // trae los últimos 60 días al conectar
  return back(true);
});
