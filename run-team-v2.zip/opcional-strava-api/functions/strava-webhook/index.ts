// Webhook de Strava (autocarga). Desplegar con: supabase functions deploy strava-webhook --no-verify-jwt
import { admin, toRow, validToken } from '../_shared/strava.ts';

async function handle(ev: any) {
  const db = admin();
  if (ev.object_type === 'athlete' && ev.updates?.authorized === 'false') {
    const { data: p } = await db.from('profiles').select('id').eq('strava_athlete_id', ev.owner_id).maybeSingle();
    if (p) { await db.from('strava_tokens').delete().eq('user_id', p.id); await db.from('profiles').update({ strava_athlete_id: null }).eq('id', p.id); }
    return;
  }
  if (ev.object_type !== 'activity') return;
  if (ev.aspect_type === 'delete') { await db.from('activities').delete().eq('strava_id', ev.object_id); return; }
  const { data: p } = await db.from('profiles').select('id').eq('strava_athlete_id', ev.owner_id).maybeSingle();
  if (!p) return;
  const token = await validToken(db, p.id); if (!token) return;
  const r = await fetch(`https://www.strava.com/api/v3/activities/${ev.object_id}`, { headers: { Authorization: `Bearer ${token}` } });
  if (!r.ok) return;
  const row = toRow(p.id, await r.json());
  if (row) await db.from('activities').upsert(row, { onConflict: 'strava_id' });
  else await db.from('activities').delete().eq('strava_id', ev.object_id);
}

Deno.serve(async (req) => {
  if (req.method === 'GET') {   // verificación de la suscripción
    const u = new URL(req.url);
    if (u.searchParams.get('hub.verify_token') === Deno.env.get('STRAVA_VERIFY_TOKEN'))
      return Response.json({ 'hub.challenge': u.searchParams.get('hub.challenge') });
    return new Response('forbidden', { status: 403 });
  }
  const ev = await req.json().catch(() => null);
  if (ev) {
    const p = handle(ev).catch((e) => console.error(e));
    // @ts-ignore EdgeRuntime existe en Supabase
    if (typeof EdgeRuntime !== 'undefined') EdgeRuntime.waitUntil(p); else await p;
  }
  return new Response('ok');   // Strava exige 200 en menos de 2 s
});
