import { createClient } from 'npm:@supabase/supabase-js@2';

export const admin = () => createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
const RUNS = ['Run', 'TrailRun', 'VirtualRun'];

export async function validToken(db: ReturnType<typeof admin>, userId: string): Promise<string | null> {
  const { data: t } = await db.from('strava_tokens').select('*').eq('user_id', userId).maybeSingle();
  if (!t) return null;
  if (t.expires_at > Math.floor(Date.now() / 1000) + 60) return t.access_token;
  const r = await fetch('https://www.strava.com/oauth/token', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: Deno.env.get('STRAVA_CLIENT_ID')!, client_secret: Deno.env.get('STRAVA_CLIENT_SECRET')!,
      grant_type: 'refresh_token', refresh_token: t.refresh_token }),
  });
  if (!r.ok) return null;
  const n = await r.json();
  await db.from('strava_tokens').update({ access_token: n.access_token, refresh_token: n.refresh_token, expires_at: n.expires_at }).eq('user_id', userId);
  return n.access_token;
}

export function toRow(userId: string, a: any) {
  const sport = a.sport_type || a.type;
  if (!RUNS.includes(sport)) return null;
  return {
    user_id: userId, strava_id: a.id, source: 'strava', name: a.name, sport,
    started_at: a.start_date, date: String(a.start_date_local).slice(0, 10),
    km: Math.round((a.distance / 1000) * 100) / 100, moving_sec: a.moving_time, elev: a.total_elevation_gain ?? 0,
  };
}

export async function syncRecent(db: ReturnType<typeof admin>, userId: string, days = 60) {
  const token = await validToken(db, userId); if (!token) return 0;
  const after = Math.floor(Date.now() / 1000) - days * 86400;
  let n = 0;
  for (let page = 1; page <= 5; page++) {
    const r = await fetch(`https://www.strava.com/api/v3/athlete/activities?after=${after}&per_page=100&page=${page}`, { headers: { Authorization: `Bearer ${token}` } });
    if (!r.ok) break;
    const list = await r.json(); if (!list.length) break;
    const rows = list.map((a: any) => toRow(userId, a)).filter(Boolean);
    if (rows.length) { await db.from('activities').upsert(rows, { onConflict: 'strava_id' }); n += rows.length; }
    if (list.length < 100) break;
  }
  return n;
}
