# Run Team (Android + iPhone)

Expo (React Native) + Supabase. Las actividades se suben importando el activities.csv de Strava o a mano.
(La conexión automática con la API de Strava está en `opcional-strava-api/`, pero Strava exige suscripción y limita mostrar los datos a su dueño.)

## 1. Supabase
SQL Editor -> pega y ejecuta `supabase/schema.sql`.
Si ya lo habías ejecutado antes, ejecuta solo esto:
```sql
drop policy a_ins on activities;
create policy a_ins on activities for insert to authenticated
  with check (user_id=auth.uid() and source in ('manual','import'));
```

## 2. La app (en el terminal)
```bash
npx create-expo-app@latest runteam --template blank
cd runteam
npx expo install @supabase/supabase-js @react-native-async-storage/async-storage react-native-url-polyfill expo-document-picker
```
Copia dentro: `App.js`, la carpeta `src/`, `app.json`, `eas.json`.
Crea `.env` (copia `.env.example`) con tu URL y clave de Supabase. Borra la línea de Strava.
Cambia `com.tuequipo.runteam` por tu identificador.

## 3. APK
```bash
npm i -g eas-cli && eas login
eas build -p android --profile preview
```
Enlace de descarga del .apk al terminar. Pon las variables EXPO_PUBLIC_* en eas.json (`"env"`).

## iPhone
Necesita cuenta Apple Developer (99 USD/año): `eas build -p ios`.

## Uso
El primer usuario registrado es Coach (cambia roles en Equipo).
