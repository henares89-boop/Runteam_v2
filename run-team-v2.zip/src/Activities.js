import React, { useState } from 'react';
import { View, Text, ScrollView, Modal, TextInput, Alert, SafeAreaView, Pressable } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { supabase } from './supabase';
import { Btn, C, Chip, s } from './ui';
import { fmtD, fmtDur, fmtPace, mondayOf, num, pad, ymd, weekKm } from './util';

/* ---------- lectura del activities.csv de Strava ---------- */
function parseCSV(t) {
  const rows = []; let r = [], f = '', q = false;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (q) { if (c === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === ',') { r.push(f); f = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; r.push(f); f = ''; if (r.length > 1 || r[0] !== '') rows.push(r); r = []; }
    else f += c;
  }
  if (f !== '' || r.length) { r.push(f); rows.push(r); }
  return rows;
}
const norm = (x) => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
const MONTHS = { ene: 0, jan: 0, feb: 1, mar: 2, abr: 3, apr: 3, may: 4, jun: 5, jul: 6, ago: 7, aug: 7, sep: 8, set: 8, oct: 9, nov: 10, dic: 11, dec: 11 };
function parseDate(str) {
  str = String(str || '').trim(); if (!str) return null;
  const m = str.match(/(\d{1,2})\s*(?:de\s+)?([A-Za-zÀ-ÿ]+)\.?\s*,?\s*(?:de\s+)?(\d{4})(?:[,\s]+(\d{1,2}):(\d{2}))?/);
  if (m && MONTHS[norm(m[2]).slice(0, 3)] != null) return new Date(+m[3], MONTHS[norm(m[2]).slice(0, 3)], +m[1], +(m[4] || 12), +(m[5] || 0));
  const d = new Date(str); return isNaN(d) ? null : d;
}
const toNum = (v) => { v = String(v || '').trim(); if (!v) return NaN; if (v.includes(',') && !v.includes('.')) v = v.replace(',', '.'); else v = v.replace(/,/g, ''); return parseFloat(v); };
function readStrava(text) {
  const rows = parseCSV(text.replace(/^\uFEFF/, '')); if (rows.length < 2) throw new Error('El archivo está vacío');
  const H = rows[0].map(norm);
  const all = (names) => H.map((h, i) => (names.includes(h) ? i : -1)).filter((i) => i >= 0);
  const iId = all(['activity id', 'id de actividad', 'id de la actividad']), iDate = all(['activity date', 'fecha de la actividad', 'fecha de actividad']),
    iName = all(['activity name', 'nombre de la actividad', 'nombre de actividad']), iType = all(['activity type', 'tipo de actividad']),
    iDist = all(['distance', 'distancia']), iMov = all(['moving time', 'tiempo en movimiento']), iEl = all(['elapsed time', 'tiempo transcurrido']),
    iElev = all(['elevation gain', 'desnivel positivo', 'ganancia de elevacion']);
  if (!iDate.length || !iDist.length || !iId.length) throw new Error('Este archivo no parece el activities.csv de Strava');
  const last = (row, idx) => { for (let k = idx.length - 1; k >= 0; k--) { const n = toNum(row[idx[k]]); if (!isNaN(n)) return n; } return NaN; };
  const out = [];
  rows.slice(1).forEach((row) => {
    const d = parseDate(row[iDate[0]]); if (!d) return;
    let km = last(row, iDist); if (isNaN(km)) return; if (km > 300) km = km / 1000;
    let sec = last(row, iMov); if (isNaN(sec) || sec <= 0) sec = last(row, iEl); if (isNaN(sec)) sec = 0;
    const sport = iType.length ? String(row[iType[0]] || '') : '';
    const sid = String(row[iId[0]] || '').replace(/\D/g, '');
    if (!sid || !/run|carrera|correr|trail|corrida/i.test(sport)) return;
    out.push({ strava_id: Number(sid), date: ymd(d), started_at: ymd(d) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':00Z',
      name: (iName.length && row[iName[0]]) || 'Carrera', sport, km: Math.round(km * 100) / 100, moving_sec: Math.round(sec), elev: Math.round(last(row, iElev)) || 0 });
  });
  return out;
}

/* ---------- pantalla ---------- */
export default function Activities({ me, data, reload, openComments }) {
  const [viewer, setViewer] = useState(me.id);
  const [manual, setManual] = useState(false);
  const [imp, setImp] = useState(false);
  const runners = data.profiles.filter((p) => p.role !== 'socio');
  const list = data.acts.filter((a) => viewer === 'all' || a.user_id === viewer);
  const nm = (id) => data.profiles.find((p) => p.id === id)?.name || '—';
  const cnt = (id) => data.cc.filter((c) => c.target_type === 'activity' && c.target_id === String(id)).length;
  const ws = mondayOf(ymd(new Date()));
  const canAdd = me.role !== 'socio';

  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      {canAdd && (
        <View style={s.card}>
          <Text style={{ fontWeight: '800', fontSize: 16 }}>Subir mis actividades</Text>
          <Text style={[s.muted, { marginVertical: 6 }]}>Importa el archivo de Strava o añádelas a mano. Las tareas se marcan solas si hay una carrera ese día.</Text>
          <View style={{ gap: 8 }}>
            <Btn title="Importar archivo de Strava" onPress={() => setImp(true)} />
            <Btn kind="ghost" title="+ Añadir a mano" onPress={() => setManual(true)} />
          </View>
        </View>
      )}
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <Chip label="Todo el equipo" on={viewer === 'all'} onPress={() => setViewer('all')} />
        {runners.map((r) => <Chip key={r.id} label={r.id === me.id ? 'Yo' : (r.name || '').split(' ')[0]} on={viewer === r.id} onPress={() => setViewer(r.id)} />)}
      </ScrollView>
      <View style={[s.card, { flexDirection: 'row', justifyContent: 'space-around' }]}>
        <Stat v={num((viewer === 'all' ? runners.map((r) => r.id) : [viewer]).reduce((x, id) => x + weekKm(id, ws, data.acts), 0)) + ' km'} l="Esta semana" />
        <Stat v={list.length} l="Actividades" />
        <Stat v={num(list.reduce((x, a) => x + Number(a.km), 0), 0) + ' km'} l="Últ. 120 días" />
      </View>
      {!list.length && <Text style={[s.muted, { textAlign: 'center', marginTop: 24 }]}>Todavía no hay actividades.</Text>}
      {list.slice(0, 80).map((a) => (
        <Pressable key={a.id} onPress={() => openComments({ type: 'activity', id: a.id, title: a.name })} style={s.card}>
          <View style={[s.row, { justifyContent: 'space-between' }]}>
            <Text style={{ fontWeight: '800', fontSize: 16 }}>{num(a.km, 2)} km <Text style={{ fontWeight: '400' }}>· {fmtDur(a.moving_sec)} · {fmtPace(a.moving_sec, a.km)}</Text></Text>
            <Text style={s.muted}>💬 {cnt(a.id)}</Text>
          </View>
          <Text style={s.muted}>{nm(a.user_id)} · {fmtD(a.date)} · {a.name} · {a.source === 'import' ? 'Strava (archivo)' : 'manual'}</Text>
          {(a.user_id === me.id || me.role === 'coach') && (
            <Text style={{ color: C.danger, fontSize: 12, marginTop: 4 }} onPress={() => Alert.alert('¿Eliminar actividad?', '', [{ text: 'Cancelar' }, { text: 'Eliminar', style: 'destructive', onPress: async () => { await supabase.from('activities').delete().eq('id', a.id); reload(); } }])}>Eliminar</Text>
          )}
        </Pressable>
      ))}
      <Manual visible={manual} onClose={() => setManual(false)} me={me} reload={reload} />
      <ImportStrava visible={imp} onClose={() => setImp(false)} me={me} reload={reload} />
    </ScrollView>
  );
}
const Stat = ({ v, l }) => <View style={{ alignItems: 'center' }}><Text style={{ fontWeight: '800', fontSize: 17 }}>{v}</Text><Text style={s.muted}>{l}</Text></View>;

function ImportStrava({ visible, onClose, me, reload }) {
  const [rows, setRows] = useState(null); const [per, setPer] = useState(90); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState('');
  const cut = per ? ymd(new Date(Date.now() - per * 864e5)) : '0000-00-00';
  const sel = (rows || []).filter((r) => r.date >= cut);
  const pick = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true });
      if (res.canceled) return;
      const text = await (await fetch(res.assets[0].uri)).text();
      setRows(readStrava(text)); setMsg('');
    } catch (e) { setRows(null); setMsg(String(e.message || e)); }
  };
  const go = async () => {
    setBusy(true);
    for (let i = 0; i < sel.length; i += 100) {
      const chunk = sel.slice(i, i + 100).map((r) => ({ ...r, user_id: me.id, source: 'import' }));
      const { error } = await supabase.from('activities').upsert(chunk, { onConflict: 'strava_id', ignoreDuplicates: true });
      if (error) { setBusy(false); return Alert.alert('Error', error.message); }
    }
    setBusy(false); setRows(null); onClose(); reload();
    Alert.alert('Listo', 'Actividades importadas. Las que ya estaban se han omitido.');
  };
  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
        <ScrollView contentContainerStyle={{ padding: 16 }}>
          <Text style={{ fontSize: 18, fontWeight: '800' }}>Importar de Strava</Text>
          <Text style={{ marginTop: 10, lineHeight: 22 }}>
            1. En Strava (web): Configuración → Mi cuenta → Descarga o elimina tu cuenta → Solicitar tu archivo.{'\n'}
            2. Te llega un email con un ZIP. Descárgalo y, en la app Archivos, tócalo y elige Extraer.{'\n'}
            3. Pulsa el botón y elige el archivo activities.csv.{'\n'}
            Puedes repetirlo cuando quieras: no se duplican.
          </Text>
          <View style={{ marginTop: 14 }}><Btn title="Elegir activities.csv" onPress={pick} disabled={busy} /></View>
          {!!msg && <Text style={{ color: C.danger, marginTop: 10 }}>{msg}</Text>}
          {rows && (
            <View style={{ marginTop: 14 }}>
              <Text style={s.label}>Periodo</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {[[90, '3 meses'], [180, '6 meses'], [365, '1 año'], [0, 'Todo']].map(([v, l]) => <Chip key={v} label={l} on={per === v} onPress={() => setPer(v)} />)}
              </ScrollView>
              <View style={s.card}><Text>{rows.length} carreras en el archivo · {sel.length} en este periodo</Text></View>
              <Btn title={busy ? 'Importando…' : `Importar ${sel.length} carreras`} onPress={go} disabled={busy || !sel.length} />
            </View>
          )}
          <View style={{ marginTop: 14 }}><Btn kind="ghost" title="Cerrar" onPress={onClose} /></View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}

function Manual({ visible, onClose, me, reload }) {
  const [date, setDate] = useState(ymd(new Date())); const [km, setKm] = useState(''); const [min, setMin] = useState(''); const [name, setName] = useState('');
  const save = async () => {
    const k = parseFloat(km.replace(',', '.')), m = parseFloat(min.replace(',', '.'));
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !(k > 0) || !(m > 0)) return Alert.alert('Revisa los datos', 'Fecha AAAA-MM-DD, km y minutos son obligatorios.');
    const { error } = await supabase.from('activities').insert({ user_id: me.id, date, started_at: date + 'T12:00:00Z', name: name || 'Carrera', sport: 'Run', km: k, moving_sec: Math.round(m * 60), source: 'manual' });
    if (error) return Alert.alert('Error', error.message);
    setKm(''); setMin(''); setName(''); onClose(); reload();
  };
  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <SafeAreaView style={{ flex: 1, padding: 16, backgroundColor: C.bg }}>
        <Text style={{ fontSize: 18, fontWeight: '800' }}>Actividad manual</Text>
        <Text style={s.label}>Fecha (AAAA-MM-DD)</Text><TextInput style={s.input} value={date} onChangeText={setDate} />
        <Text style={s.label}>Distancia (km)</Text><TextInput style={s.input} keyboardType="decimal-pad" value={km} onChangeText={setKm} />
        <Text style={s.label}>Duración (minutos)</Text><TextInput style={s.input} keyboardType="decimal-pad" value={min} onChangeText={setMin} />
        <Text style={s.label}>Nombre</Text><TextInput style={s.input} value={name} onChangeText={setName} placeholder="Rodaje matinal" />
        <View style={{ marginTop: 16, gap: 8 }}><Btn title="Guardar" onPress={save} /><Btn kind="ghost" title="Cancelar" onPress={onClose} /></View>
      </SafeAreaView>
    </Modal>
  );
}
