import React, { useState } from 'react';
import { View, Text, ScrollView, Modal, TextInput, Alert, SafeAreaView, Pressable } from 'react-native';
import { supabase } from './supabase';
import { Btn, C, Chip, Pill, s } from './ui';
import { DIA, TYPES, NON_RUN, addDays, fmtRange, mondayOf, num, parse, taskStatus, forUser, weekKm, ymd } from './util';

const TODAY = ymd(new Date());

export default function Week({ me, data, reload, openComments }) {
  const [ws, setWs] = useState(mondayOf(TODAY));
  const [viewer, setViewer] = useState(me.id);
  const [form, setForm] = useState(null);
  const [focusForm, setFocusForm] = useState(null);
  const isCoach = me.role === 'coach';
  const runners = data.profiles.filter((p) => p.role !== 'socio');
  const nm = (id) => data.profiles.find((p) => p.id === id)?.name || '—';
  const cnt = (t, id) => data.cc.filter((c) => c.target_type === t && c.target_id === String(id)).length;
  const wk = data.weeks.find((w) => w.week_start === ws);
  const tasks = data.tasks.filter((t) => t.week_start === ws && (viewer === 'all' || forUser(t, viewer)));
  const prev = data.tasks.filter((t) => t.week_start === addDays(ws, -7));

  const toggle = async (t) => {
    const mine = data.done.some((d) => d.task_id === t.id && d.user_id === me.id);
    const q = mine ? supabase.from('task_done').delete().eq('task_id', t.id).eq('user_id', me.id) : supabase.from('task_done').insert({ task_id: t.id, user_id: me.id });
    const { error } = await q; if (error) Alert.alert('Error', error.message); reload();
  };
  const copyPrev = async () => {
    const rows = prev.map(({ id, created_at, ...r }) => ({ ...r, week_start: ws }));
    const { error } = await supabase.from('tasks').insert(rows); if (error) Alert.alert('Error', error.message); reload();
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <View style={[s.row, { justifyContent: 'space-between' }]}>
        <Btn kind="ghost" title="‹" onPress={() => setWs(addDays(ws, -7))} />
        <View style={{ alignItems: 'center' }}>
          <Text style={{ fontSize: 17, fontWeight: '800' }}>{fmtRange(ws)}</Text>
          <Text style={s.muted} onPress={() => setWs(mondayOf(TODAY))}>{ws === mondayOf(TODAY) ? 'Esta semana' : 'Ir a hoy'}</Text>
        </View>
        <Btn kind="ghost" title="›" onPress={() => setWs(addDays(ws, 7))} />
      </View>

      <View style={s.card}>
        <View style={[s.row, { justifyContent: 'space-between' }]}>
          <Text style={s.h2}>Objetivo de la semana</Text>
          {isCoach && <Btn kind="ghost" small title="Editar" onPress={() => setFocusForm(wk?.focus || '')} />}
        </View>
        <Text>{wk?.focus || 'Sin objetivo definido todavía.'}</Text>
        <View style={{ marginTop: 10 }}><Btn kind="ghost" small title={`💬 Comentarios de la semana (${cnt('week', ws)})`} onPress={() => openComments({ type: 'week', id: ws, title: 'Semana ' + fmtRange(ws) })} /></View>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 6 }}>
        <Chip label="Todo el equipo" on={viewer === 'all'} onPress={() => setViewer('all')} />
        {runners.map((r) => <Chip key={r.id} label={r.id === me.id ? 'Yo' : (r.name || '').split(' ')[0]} on={viewer === r.id} onPress={() => setViewer(r.id)} />)}
      </ScrollView>

      <View style={s.card}>
        {(viewer === 'all' ? runners : runners.filter((r) => r.id === viewer)).map((r) => {
          const km = weekKm(r.id, ws, data.acts);
          const plan = data.tasks.filter((t) => t.week_start === ws && forUser(t, r.id) && !NON_RUN.includes(t.type)).reduce((x, t) => x + Number(t.km || 0), 0) || Number(r.goal_km || 0);
          const pc = plan ? Math.min(100, (km / plan) * 100) : 0;
          return (
            <View key={r.id} style={{ marginVertical: 6 }}>
              <View style={[s.row, { justifyContent: 'space-between' }]}><Text style={{ fontWeight: '700' }}>{r.name}</Text><Text><Text style={{ fontWeight: '800' }}>{num(km)}</Text> / {num(plan, 0)} km</Text></View>
              <View style={{ height: 8, borderRadius: 9, backgroundColor: C.line, marginTop: 5 }}><View style={{ height: 8, borderRadius: 9, width: pc + '%', backgroundColor: pc >= 100 ? C.ok : C.accent }} /></View>
            </View>
          );
        })}
      </View>

      {!data.tasks.some((t) => t.week_start === ws) && (
        <View style={[s.card, { alignItems: 'center' }]}>
          <Text style={s.muted}>{isCoach ? 'Aún no hay tareas esta semana.' : 'El coach todavía no ha planificado esta semana.'}</Text>
          {isCoach && <View style={{ marginTop: 10, gap: 8 }}><Btn title="+ Añadir tarea" onPress={() => setForm({})} />{prev.length > 0 && <Btn kind="ghost" title="Copiar semana anterior" onPress={copyPrev} />}</View>}
        </View>
      )}

      {[0, 1, 2, 3, 4, 5, 6, 7].map((d) => {
        const list = tasks.filter((t) => (t.day == null ? d === 7 : t.day === d));
        const date = d < 7 ? addDays(ws, d) : null;
        const acts = date && viewer !== 'all' ? data.acts.filter((a) => a.user_id === viewer && a.date === date) : [];
        if (!list.length && !acts.length) return null;
        return (
          <View key={d} style={{ marginTop: 14 }}>
            <Text style={{ fontWeight: '800', fontSize: 15 }}>{d < 7 ? DIA[d] + ' ' + parse(date).getDate() : 'Sin día fijo'}{date === TODAY ? '  · HOY' : ''}</Text>
            {list.map((t) => {
              const [label, color] = TYPES[t.type] || TYPES.rodaje;
              let st;
              if (viewer !== 'all') { const x = taskStatus(t, viewer, data); st = x.done ? <Pill kind="ok" label={'✓ Hecha' + (x.how === 'auto' ? ' · Strava' : '')} /> : x.partial ? <Pill kind="warn" label={`Parcial · ${num(x.km)} km`} /> : <Pill label="Pendiente" />; }
              else { const rs = runners.filter((r) => forUser(t, r.id)); const ok = rs.filter((r) => taskStatus(t, r.id, data).done).length; st = <Pill kind={ok && ok === rs.length ? 'ok' : undefined} label={`${ok}/${rs.length} hechas`} />; }
              const mine = viewer === me.id && forUser(t, me.id);
              const meDone = data.done.some((x) => x.task_id === t.id && x.user_id === me.id);
              return (
                <View key={t.id} style={[s.card, { borderLeftWidth: 5, borderLeftColor: color }]}>
                  <View style={[s.row, { justifyContent: 'space-between' }]}>
                    <View style={{ flex: 1 }}><Text style={{ fontWeight: '700', fontSize: 16 }}>{t.title}</Text>
                      <Text style={s.muted}>{[label, t.km ? num(t.km) + ' km' : '', t.assignee ? 'Para ' + nm(t.assignee).split(' ')[0] : ''].filter(Boolean).join(' · ')}</Text></View>
                    {isCoach && <Text style={{ color: C.muted }} onPress={() => setForm(t)}>Editar</Text>}
                  </View>
                  {!!t.notes && <Text style={{ marginTop: 6 }}>{t.notes}</Text>}
                  <View style={[s.row, { marginTop: 10, flexWrap: 'wrap' }]}>
                    {st}
                    {mine && <Btn kind="ghost" small title={meDone ? 'Quitar marca' : 'Marcar hecha'} onPress={() => toggle(t)} />}
                    <Btn kind="ghost" small title={`💬 ${cnt('task', t.id)}`} onPress={() => openComments({ type: 'task', id: t.id, title: t.title })} />
                  </View>
                </View>
              );
            })}
            {acts.map((a) => (
              <Pressable key={a.id} onPress={() => openComments({ type: 'activity', id: a.id, title: a.name })} style={{ backgroundColor: C.okSoft, borderRadius: 12, padding: 10, marginVertical: 4 }}>
                <Text><Text style={{ fontWeight: '800' }}>{num(a.km, 2)} km</Text> · {a.name} · {a.source === 'import' ? 'Strava (archivo)' : 'manual'}</Text>
              </Pressable>
            ))}
          </View>
        );
      })}
      {isCoach && data.tasks.some((t) => t.week_start === ws) && <View style={{ marginTop: 16 }}><Btn title="+ Añadir tarea" onPress={() => setForm({})} /></View>}

      <TaskForm form={form} ws={ws} runners={runners} onClose={() => setForm(null)} reload={reload} />
      <Modal visible={focusForm !== null} animationType="slide" onRequestClose={() => setFocusForm(null)}>
        <SafeAreaView style={{ flex: 1, padding: 16, backgroundColor: C.bg }}>
          <Text style={{ fontSize: 18, fontWeight: '800' }}>Objetivo · {fmtRange(ws)}</Text>
          <TextInput style={[s.input, { minHeight: 140 }]} multiline value={focusForm || ''} onChangeText={setFocusForm} />
          <View style={{ marginTop: 14, gap: 8 }}>
            <Btn title="Guardar" onPress={async () => { await supabase.from('weeks').upsert({ week_start: ws, focus: focusForm }); setFocusForm(null); reload(); }} />
            <Btn kind="ghost" title="Cancelar" onPress={() => setFocusForm(null)} />
          </View>
        </SafeAreaView>
      </Modal>
    </ScrollView>
  );
}

function TaskForm({ form, ws, runners, onClose, reload }) {
  const [f, setF] = useState({});
  React.useEffect(() => { if (form) setF({ type: 'rodaje', day: null, assignee: null, ...form, km: form.km != null ? String(form.km) : '' }); }, [form]);
  if (!form) return null;
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }));
  const save = async () => {
    if (!f.title?.trim()) return Alert.alert('Pon un título');
    const row = { week_start: form.week_start || ws, title: f.title.trim(), type: f.type, day: f.day, km: f.km ? parseFloat(String(f.km).replace(',', '.')) : null, notes: f.notes || null, assignee: f.assignee };
    const { error } = form.id ? await supabase.from('tasks').update(row).eq('id', form.id) : await supabase.from('tasks').insert(row);
    if (error) return Alert.alert('Error', error.message);
    onClose(); reload();
  };
  const del = () => Alert.alert('¿Eliminar tarea?', '', [{ text: 'Cancelar' }, { text: 'Eliminar', style: 'destructive', onPress: async () => { await supabase.from('tasks').delete().eq('id', form.id); onClose(); reload(); } }]);
  return (
    <Modal visible animationType="slide" onRequestClose={onClose}>
      <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
        <ScrollView contentContainerStyle={{ padding: 16 }}>
          <Text style={{ fontSize: 18, fontWeight: '800' }}>{form.id ? 'Editar tarea' : 'Nueva tarea'}</Text>
          <Text style={s.label}>Título</Text><TextInput style={s.input} value={f.title} onChangeText={set('title')} placeholder="Ej. Rodaje suave + progresivos" />
          <Text style={s.label}>Tipo</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>{Object.keys(TYPES).map((k) => <Chip key={k} label={TYPES[k][0]} on={f.type === k} onPress={() => set('type')(k)} />)}</ScrollView>
          <Text style={s.label}>Día</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Chip label="Sin día" on={f.day == null} onPress={() => set('day')(null)} />
            {DIA.map((d, i) => <Chip key={d} label={d.slice(0, 3)} on={f.day === i} onPress={() => set('day')(i)} />)}
          </ScrollView>
          <Text style={s.label}>Distancia objetivo (km)</Text><TextInput style={s.input} keyboardType="decimal-pad" value={f.km} onChangeText={set('km')} />
          <Text style={s.label}>Asignada a</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Chip label="Todo el equipo" on={!f.assignee} onPress={() => set('assignee')(null)} />
            {runners.map((r) => <Chip key={r.id} label={(r.name || '').split(' ')[0]} on={f.assignee === r.id} onPress={() => set('assignee')(r.id)} />)}
          </ScrollView>
          <Text style={s.label}>Detalle (ritmos, series, sensaciones…)</Text>
          <TextInput style={[s.input, { minHeight: 90 }]} multiline value={f.notes || ''} onChangeText={set('notes')} />
          <View style={{ marginTop: 18, gap: 8 }}>
            <Btn title="Guardar" onPress={save} />
            {!!form.id && <Btn kind="danger" title="Eliminar" onPress={del} />}
            <Btn kind="ghost" title="Cancelar" onPress={onClose} />
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}
