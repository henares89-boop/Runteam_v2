export const pad = (n) => String(n).padStart(2, '0');
export const ymd = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
export const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
export const addDays = (s, n) => { const d = parse(s); d.setDate(d.getDate() + n); return ymd(d); };
export const mondayOf = (s) => { const d = parse(s); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return ymd(d); };
const MES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
export const DIA = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
export const fmtD = (s) => { const d = parse(s); return d.getDate() + ' ' + MES[d.getMonth()]; };
export const fmtRange = (ws) => fmtD(ws) + ' – ' + fmtD(addDays(ws, 6));
export const num = (n, dec = 1) => Number(n || 0).toLocaleString('es-ES', { maximumFractionDigits: dec });
export const fmtDur = (s) => { s = Math.round(s || 0); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h}:${pad(m)}:${pad(s % 60)}` : `${m}:${pad(s % 60)}`; };
export const fmtPace = (sec, km) => { if (!km || !sec) return '–'; const p = sec / km; return Math.floor(p / 60) + ':' + pad(Math.min(59, Math.round(p % 60))) + '/km'; };
export const TYPES = {
  rodaje: ['Rodaje', '#2e9e6b'], series: ['Series', '#e5484d'], tempo: ['Tempo', '#f08a24'],
  larga: ['Tirada larga', '#3e63dd'], fuerza: ['Fuerza', '#8e4ec6'], descanso: ['Descanso', '#889096'], competicion: ['Competición', '#d6409f'],
};
export const NON_RUN = ['fuerza', 'descanso'];
export const ROLES = { coach: 'Coach', runner: 'Corredor/a', socio: 'Socio/a' };

// ¿Está hecha la tarea para este usuario? (marca manual o carrera de Strava ese día)
export function taskStatus(t, uid, data) {
  if (data.done.some((d) => d.task_id === t.id && d.user_id === uid)) return { done: true, how: 'manual' };
  if (t.day != null && !NON_RUN.includes(t.type)) {
    const date = addDays(t.week_start, t.day);
    const as = data.acts.filter((a) => a.user_id === uid && a.date === date);
    const km = as.reduce((s, a) => s + Number(a.km), 0);
    if (as.length && (!t.km || km >= Number(t.km) * 0.8)) return { done: true, how: 'auto', km };
    if (as.length) return { partial: true, km };
  }
  return { done: false };
}
export const forUser = (t, uid) => !t.assignee || t.assignee === uid;
export const weekKm = (uid, ws, acts) => acts.filter((a) => a.user_id === uid && a.date >= ws && a.date <= addDays(ws, 6)).reduce((s, a) => s + Number(a.km), 0);
