import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, Alert, ActionSheetIOS, Platform } from 'react-native';
import { supabase } from './supabase';
import { Btn, C, Pill, s } from './ui';
import { ROLES, mondayOf, num, weekKm, ymd } from './util';

export default function Team({ me, data, reload }) {
  const [name, setName] = useState(me.name || ''); const [goal, setGoal] = useState(String(me.goal_km ?? 30));
  const ws = mondayOf(ymd(new Date()));
  const saveMe = async () => {
    const { error } = await supabase.from('profiles').update({ name: name.trim(), goal_km: parseFloat(goal.replace(',', '.')) || 30 }).eq('id', me.id);
    if (error) Alert.alert('Error', error.message); else { Alert.alert('Guardado'); reload(); }
  };
  const changeRole = (p) => {
    const opts = Object.keys(ROLES);
    const apply = async (r) => { const { error } = await supabase.rpc('set_role', { uid: p.id, r }); if (error) Alert.alert('Error', error.message); reload(); };
    if (Platform.OS === 'ios') ActionSheetIOS.showActionSheetWithOptions({ options: [...opts.map((o) => ROLES[o]), 'Cancelar'], cancelButtonIndex: opts.length }, (i) => i < opts.length && apply(opts[i]));
    else Alert.alert('Rol de ' + p.name, '', [...opts.map((o) => ({ text: ROLES[o], onPress: () => apply(o) })), { text: 'Cancelar', style: 'cancel' }]);
  };
  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Text style={s.h2}>Mi perfil</Text>
      <View style={s.card}>
        <Pill label={ROLES[me.role]} kind={me.role === 'coach' ? 'coach' : undefined} />
        <Text style={s.label}>Nombre</Text><TextInput style={s.input} value={name} onChangeText={setName} />
        <Text style={s.label}>Objetivo semanal por defecto (km)</Text><TextInput style={s.input} keyboardType="decimal-pad" value={goal} onChangeText={setGoal} />
        <View style={{ marginTop: 12 }}><Btn title="Guardar" onPress={saveMe} /></View>
        <View style={{ marginTop: 8 }}><Btn kind="ghost" title="Cerrar sesión" onPress={() => supabase.auth.signOut()} /></View>
      </View>
      <Text style={s.h2}>Equipo</Text>
      <View style={s.card}>
        {data.profiles.map((p) => (
          <View key={p.id} style={[s.row, { paddingVertical: 10, justifyContent: 'space-between', borderBottomWidth: 1, borderColor: C.line }]}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '700' }}>{p.name}{p.id === me.id ? ' (tú)' : ''}</Text>
              <Text style={s.muted}>{num(weekKm(p.id, ws, data.acts))} km esta semana</Text>
            </View>
            {me.role === 'coach' ? <Btn kind="ghost" small title={ROLES[p.role] + ' ▾'} onPress={() => changeRole(p)} /> : <Pill label={ROLES[p.role]} kind={p.role === 'coach' ? 'coach' : undefined} />}
          </View>
        ))}
      </View>
      <Text style={[s.muted, { marginTop: 8 }]}>Coach: crea semanas y tareas y escribe notas privadas. Corredor/a: sube actividades, marca tareas y comenta. Socio/a: solo comenta. El primer usuario registrado es Coach.</Text>
    </ScrollView>
  );
}
