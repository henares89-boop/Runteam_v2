import React from 'react';
import { Pressable, Text, View, StyleSheet } from 'react-native';
export const C = { bg: '#f6f5f2', card: '#fff', text: '#1b1b1f', muted: '#6b6b76', line: '#e6e4df', accent: '#fc4c02', soft: '#fff0ea', ok: '#1f9d63', okSoft: '#e5f6ee', warn: '#c77700', warnSoft: '#fff4de', danger: '#d93a3a' };
export const s = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: 16, padding: 14, marginVertical: 6, borderWidth: 1, borderColor: C.line },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  h2: { fontSize: 12, letterSpacing: 1, color: C.muted, fontWeight: '700', marginTop: 16, marginBottom: 4, textTransform: 'uppercase' },
  muted: { color: C.muted, fontSize: 13 },
  input: { backgroundColor: C.bg, borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 10, fontSize: 16, color: C.text, marginTop: 4 },
  label: { fontSize: 12, color: C.muted, fontWeight: '600', marginTop: 12 },
});
export const Btn = ({ title, onPress, kind, small, disabled }) => (
  <Pressable onPress={onPress} disabled={disabled} style={{
    backgroundColor: kind === 'ghost' ? C.card : kind === 'danger' ? C.card : C.accent, borderWidth: kind ? 1 : 0, borderColor: C.line,
    paddingVertical: small ? 6 : 11, paddingHorizontal: small ? 10 : 16, borderRadius: 12, opacity: disabled ? 0.5 : 1, alignItems: 'center' }}>
    <Text style={{ color: kind === 'ghost' ? C.text : kind === 'danger' ? C.danger : '#fff', fontWeight: '700', fontSize: small ? 13 : 15 }}>{title}</Text>
  </Pressable>
);
export const Chip = ({ label, on, onPress }) => (
  <Pressable onPress={onPress} style={{ paddingVertical: 6, paddingHorizontal: 12, borderRadius: 99, borderWidth: 1, marginRight: 8,
    borderColor: on ? C.accent : C.line, backgroundColor: on ? C.soft : C.card }}>
    <Text style={{ color: on ? C.accent : C.text, fontWeight: on ? '700' : '400' }}>{label}</Text>
  </Pressable>
);
export const Pill = ({ label, kind }) => (
  <View style={{ alignSelf: 'flex-start', borderRadius: 99, paddingVertical: 3, paddingHorizontal: 10,
    backgroundColor: kind === 'ok' ? C.okSoft : kind === 'warn' ? C.warnSoft : kind === 'coach' ? C.soft : C.line }}>
    <Text style={{ fontSize: 12, fontWeight: '700', color: kind === 'ok' ? C.ok : kind === 'warn' ? C.warn : kind === 'coach' ? C.accent : C.muted }}>{label}</Text>
  </View>
);
