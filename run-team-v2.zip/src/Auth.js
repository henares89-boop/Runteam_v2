import React, { useState } from 'react';
import { View, Text, TextInput, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { supabase } from './supabase';
import { Btn, C, s } from './ui';

export default function Auth() {
  const [mode, setMode] = useState('in');
  const [email, setEmail] = useState(''); const [pass, setPass] = useState(''); const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    const { error } = mode === 'in'
      ? await supabase.auth.signInWithPassword({ email: email.trim(), password: pass })
      : await supabase.auth.signUp({ email: email.trim(), password: pass, options: { data: { name: name.trim() } } });
    setBusy(false);
    if (error) Alert.alert('Error', error.message);
    else if (mode === 'up') Alert.alert('Cuenta creada', 'Si tu proyecto exige confirmar el email, revisa tu bandeja y vuelve a entrar.');
  };
  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, justifyContent: 'center', padding: 24 }}>
      <Text style={{ fontSize: 32, fontWeight: '800', color: C.text }}>Run Team</Text>
      <Text style={[s.muted, { marginBottom: 20 }]}>Entrenamiento en equipo, conectado a Strava</Text>
      {mode === 'up' && <TextInput style={s.input} placeholder="Tu nombre" value={name} onChangeText={setName} />}
      <TextInput style={s.input} placeholder="Email" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
      <TextInput style={s.input} placeholder="Contraseña" secureTextEntry value={pass} onChangeText={setPass} />
      <View style={{ marginTop: 16 }}><Btn title={mode === 'in' ? 'Entrar' : 'Crear cuenta'} onPress={go} disabled={busy || !email || pass.length < 6} /></View>
      <View style={{ marginTop: 10 }}><Btn kind="ghost" title={mode === 'in' ? 'Soy nuevo: crear cuenta' : 'Ya tengo cuenta'} onPress={() => setMode(mode === 'in' ? 'up' : 'in')} /></View>
    </KeyboardAvoidingView>
  );
}
